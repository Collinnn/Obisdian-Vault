# Kerkhoffs' principle

>[!info] Definition
> The only part of a cryptographic scheme that is secret, is the *key*

