$(2^-1)^2 = x \mod p$
$\updownarrow$
$2^2*x = 1 \mod p$
![[Pasted image 20230508152658.png]]

![[Pasted image 20230508152710.png]]
$Z_4*$ is the coprimes of the number 4
![[Pasted image 20230508152844.png]]
