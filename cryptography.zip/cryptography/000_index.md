# 000_index

>[!faq] Definition
> *The art and science of using mathematics to protect digital or personal assets, such as authentication, privacy and integrity.* 

[[database systems/books/Cryptography Made Simple.pdf | Cryptography Made Simple]]



![[course-plan-public.pdf]]