# Private-key encryption
A type of [[Encryption Scheme#Symmetric-key encryption scheme | Symmetric-key encryption scheme]]

