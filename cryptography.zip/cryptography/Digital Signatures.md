# Digital Signatures
![[2- rsa and digital signatures-22-32.pdf]]